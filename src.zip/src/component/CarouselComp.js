import { ArrowForward } from '@mui/icons-material'
import { Container, Typography } from '@mui/material'
import { getDownloadURL, ref } from 'firebase/storage'
import React, { useEffect, useState } from 'react'
import {Carousel} from 'react-bootstrap'
import { storage } from '../firebase'

const CarouselComp = () => {


  const [image, setImage] = useState('')

useEffect(() => {
  const addImage = async() => {
    const reference = ref(storage, `images/Chemistry.png`)
    await getDownloadURL(reference).then((x) => {
      setImage(x)
    })

  }
  addImage()
},[])

const [secondImage, setSecondImage] = useState('')

useEffect(() => {
  const addImage = async() => {
    const reference = ref(storage, `images/Electricity.png`)
    await getDownloadURL(reference).then((x) => {
      setSecondImage(x)
    })

  }
  addImage()
},[])

const [thirdImage, setThirdImage] = useState('')

useEffect(() => {
  const addImage = async() => {
    const reference = ref(storage, `images/Manicure.png`)
    await getDownloadURL(reference).then((x) => {
      setThirdImage(x)
    })

  }
  addImage()
},[])

const [video, setVideo] = useState('')

useEffect(() => {
  const addImage = async() => {
    const reference = ref(storage, `videos/Manicure.mov`)
    await getDownloadURL(reference).then((x) => {
      setVideo(x)
    })

  }
  addImage()
},[])


  return (
    <>
        <Carousel variant="dark" interval={null} style = {{height: '25vh'}}>
  <Carousel.Item>
    <img
    height={'100px'}
    width = {'100px'}
    style = {{margin: 'auto'}}
      className="d-block "
      src={image}
      alt="First slide"
    />
   <Container maxWidth="sm">
    <Typography
              component="h1"
              variant="h2"
              align="center"
              color="text.primary"
              gutterBottom
            >
               Welcome
            </Typography>
            <Typography variant="h5" align="center" color="text.secondary" paragraph>

            Click Arrow to see Demo!

             
            </Typography>
    </Container>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100"
      src="holder.js/800x400?text=Second slide&bg=eee"
      alt="Second slide"
    />
    <Carousel.Caption>
      <h5>Second slide label</h5>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100"
      src="holder.js/800x400?text=Third slide&bg=e5e5e5"
      alt="Third slide"
    />
    <Carousel.Caption>
      <h5>Third slide label</h5>
      <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
    </Carousel.Caption>
  </Carousel.Item>
</Carousel>
    </>
  )
}

export default CarouselComp
import { Button, Card, Container, Grid, Stack } from '@mui/material'
import React, { useEffect, useRef, useState } from 'react'
import QuizSelectionCard from './QuizSelectionCard'
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import {gridStyle, cardStyle} from './QuizSelectionCss'
import { Box } from '@mui/system';
import { Grid4x4Outlined } from '@mui/icons-material';
import { getAuth, onAuthStateChanged, signOut } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';
import { useRecoilValue } from 'recoil';
import { aUser } from '../atoms';
import {collection, doc, getDocs, query, getDoc} from 'firebase/firestore'
import { db, storage, auth } from '../firebase';
import { getDownloadURL, ref } from 'firebase/storage'
import AnimatedPage from './AnimatedPage';


const QuizSelection = () => {
   

    
    const [clicked, setClicked] = useState(false)
    const [quizzes, setQuizzes] = useState([])
    const [quizImage, setQuizImage] = useState('')
    const [videoImage, setVideoImage] = useState('')

    
    useEffect(() => {
      const addImage = async() => {
        const reference = ref(storage, `images/quizzes.png`)
        await getDownloadURL(reference).then((x) => {
          setQuizImage(x)
        })

      }
      addImage()
    },[])

    useEffect(() => {
      const addImage = async() => {
        const reference = ref(storage, `images/videos.png`)
        await getDownloadURL(reference).then((x) => {
          setVideoImage(x)
        })

      }
      addImage()
    },[])

 

 
    
    const [arrCollection, setArrCollection] = useState([])

    const [noVideoAuth, setNoVideoAuth] = useState(false)
    const [noQuizAuth, setNoQuizAuth] = useState(false)
    const [noBundleAuth, setNoBundleAuth] = useState(false)

    const [adminUser, setAdminUser] = useState(false)
    

    const navigate =  useNavigate()

    useEffect(() => {


      const videoRef = doc(db, 'Users', 'Video Pack')
      const bundleRef = doc(db, 'Users', 'Bundle Pack')
      const quizRef = doc(db, 'Users', 'Quiz Pack')

      const adminRef = doc(db, 'Users', 'Admin')
      

      getDoc(adminRef)
      .then((docu) => {

        if(auth?.currentUser?.uid === docu.data().id)
        {
          setAdminUser(true)
        }
      })

      

    getDoc(videoRef)
    .then((docu) => {

      if(!(docu.data().id.includes(auth?.currentUser?.uid))) {
        setNoVideoAuth(true)
      }
     
      
    })

    getDoc(bundleRef)
    .then((docu) => {
      
      if(!(docu.data().id.includes(auth?.currentUser?.uid))) {
        
        setNoBundleAuth(true)
      }
    
    })

    getDoc(quizRef)
    .then((docu) => {

      if(!(docu.data().id.includes(auth?.currentUser?.uid))) {
        setNoQuizAuth(true)
      }
    

    })




      const monitorAuthState = async() => {



        onAuthStateChanged(auth, user => {
          if (!user) {
            navigate('/')
          }
         
        })
      }

      monitorAuthState()

    }, [noVideoAuth, noQuizAuth, noBundleAuth, auth ])

    



  


    const logout = async() => {
      await signOut(auth)
    }

  
  
   

  return (

    <Grid>
      

      <Box
          sx={{
            bgcolor: 'background.paper',
            pt: 8,
            pb: 6,
          }}
        
        >


          <Container maxWidth="sm">
          <Card elevation={10} style = {{padding: '40px', borderRadius: '10px'}}>
            <Typography
              component="h1"
              variant="h2"
              align="center"
              color="text.primary"
              gutterBottom
            >
               Dashboard
            </Typography>
            <Typography variant="h5" align="center" color="text.secondary" paragraph>

            Signed in as: {auth?.currentUser?.email}
            {/* These sections contain test like questions that are divided to help you focus in on each individual topic.
            If you see terms you are unfamiliar with, please research them further for better understanding */}

             
            </Typography>
            <Stack
              sx={{ pt: 4 }}
              direction="row"
              spacing={2}
              justifyContent="center"
            >


<Button hidden = {!adminUser}  onClick={() => navigate('/admin')} variant="outlined">Admin</Button>
              
              <Button onClick={logout} variant="contained">Sign Out</Button>
              
              
              
              
            </Stack>
            </Card>
          </Container>

        </Box>

{/* new grid system */}






  {/* new */}

  {/* {(noBundleAuth && noVideoAuth && noQuizAuth) &&
  'Loading'
  } */}

  {/*  */}


  <Container sx={{ py: 8 }} maxWidth="md">
    
    <Grid container spacing={4}>
     
<Grid  item key={''} xs={12} sm={6} md={6} >
                <Card
               key={''}
                elevation={10}
                  sx={{ height: '100%', display: 'flex', flexDirection: 'column', borderRadius: '10px' }}
                >

<CardMedia
        component="img"
        height="140"
        style={{objectFit: 'contain', paddingTop: '30px'}}
        image={quizImage}
        
        
      />
                  
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography gutterBottom variant="h5" component="h2" align='center'>
                    <Button disabled = {noQuizAuth && noBundleAuth} onClick={() => navigate('/quizselection')} variant="outlined">Written</Button>
                    </Typography>
                   
                  </CardContent>
                  
                </Card>
  </Grid>
<Grid item key={''} xs={12} sm={6} md={6}>
                <Card

               key={''}
                
                
                elevation={10}
                  sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}
                >

<CardMedia
        component="img"
        height="140"
        style={{objectFit: 'contain', paddingTop: '30px'}}
        image={videoImage}
        
        
      />
                  
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography gutterBottom variant="h5" component="h2" align='center'>
                      <Button disabled = {noVideoAuth && noBundleAuth} onClick={() => navigate('/videoselection')} variant="outlined">Practical</Button>
                    </Typography>
                   
                  </CardContent>
                </Card>
  </Grid>
    </Grid>
  </Container>
 

</Grid>








    
  )
}

export default QuizSelection
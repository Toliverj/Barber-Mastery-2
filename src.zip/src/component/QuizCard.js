// This is the basic generated flashcard for the studying section not the random quiz card which is called GeneratedQuizCard

import React, { useEffect, useState } from 'react'
import { cardStyle } from './QuizSelectionCss'
import { CardActionArea, CardContent, Typography, Card, CardMedia, Grid, Container } from '@mui/material'
import { useNavigate } from 'react-router-dom'
import { Box } from '@mui/system'
import { Delete, Edit } from '@mui/icons-material'
import { arrayRemove } from 'firebase/firestore'

const QuizCard = ({question, answer, choices, summary, number, admin}) => {
    const [clicked, setClicked] = useState(false)

    const navigate = useNavigate()


 

  return (

    // new grid
    

    <Grid item  xs={12} sm={6} md={4}>
     
    <Card
    onClick={() => setClicked(!clicked)}
    elevation={10}
      sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}
      style = {{height: '300px', cursor:'pointer', borderRadius: '10px'}}
    >

     
      
      <CardContent sx={{ flexGrow: 1 }}>
     
  
        
        {clicked == false ? (<Typography gutterBottom paddingBottom = '5px' variant="body1" component="h4" align='center' justifyContent = 'center' style={{color: '#5885AF', display: 'grid', placeItems: 'center', height: '25vh'}}>{question}</Typography>) : (<><Typography gutterBottom paddingBottom = '5px' variant="body1" component="h4" align='center' justifyContent = 'center'><span style={{color: '#76B947'}}>Answer: </span>{answer}</Typography></>)}
        
        
        <Typography color= 'text.secondary' variant='body2'>

        {clicked == true && 
        (summary.map((ans, i) => (
          <Box key={i} m = {1}> {ans}</Box>
        )))
        }

        </Typography>
      </CardContent>
    </Card>
</Grid>



    
  )
}

export default QuizCard
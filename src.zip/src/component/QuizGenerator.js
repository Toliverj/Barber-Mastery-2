import { AppBar, Button, Container, Fab, Grid, IconButton, Stack, styled, Toolbar } from '@mui/material'
import React, { useEffect, useRef, useState } from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import {gridStyle, cardStyle} from './QuizSelectionCss'
import { Box } from '@mui/system';
import HomeIcon from '@mui/icons-material/Home';
import { useParams, useNavigate, Link } from 'react-router-dom';
import QuizCard from './QuizCard';
import { useRecoilState, useRecoilValue } from 'recoil';
import { aUser, clicks, score } from '../atoms';
import { collection, doc, getDoc, getDocFromCache, getDocs, query, where } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import {ref, getDownloadURL} from 'firebase/storage'
import {storage} from '../firebase'
import GeneratedQuizCard from './GeneratedQuizCard';
import { AccessTime, Lock, LockClock, Menu, PunchClock } from '@mui/icons-material';
import { ClockPicker } from '@mui/lab';
import '../App.css'

function Copyright(props) {
  return (
    <Typography variant="body2" color="text.secondary" align="center" {...props}>
      <Typography> Contact: jhaelintoliver1@live.com</Typography>
      {'Copyright © '}
      <Link color="inherit" href="https://mui.com/">
        jTol_Cuts
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}


const QuizGenerator = () => {



    const array = ['Define Gravity',2,3,4,5,6,7,8,9,1,2,3,4,5,6,7,]
    const navigate = useNavigate()
    const [questions, setQuestions] = useState([])
    const [summary, setSummary] = useState('')
    const [image, setImage] = useState('')

    const newInfo = useRef([])
    const questionsArr = useRef([])

   

   
    

    const {id} = useParams()

   

    const [noVideoAuth, setNoVideoAuth] = useState(false)
    const [noQuizAuth, setNoQuizAuth] = useState(false)
    const [noBundleAuth, setNoBundleAuth] = useState(false)

    const [arrCollection, setArrCollection] = useState([])

    useEffect(() => {

      const videoRef = doc(db, 'Users', 'Video Pack')
      const bundleRef = doc(db, 'Users', 'Bundle Pack')
      const quizRef = doc(db, 'Users', 'Quiz Pack')

      

    getDoc(videoRef)
    .then((docu) => {
      //console.log(docu.data().id)
      //console.log(auth.currentUser.uid)

      if(!(docu.data().id.includes(auth?.currentUser?.uid))) {
        //console.log('no video auth')
        setNoVideoAuth(true)
      
      }
      else {
        //console.log('yes video auth')
      }
      
    })

    getDoc(bundleRef)
    .then((docu) => {
      //console.log(docu.data().id)
      //console.log(auth.currentUser.uid)

      if(!(docu.data().id.includes(auth?.currentUser?.uid))) {
       // console.log('no bundle auth')
        setNoBundleAuth(true)
       
      }
      else {
       // console.log('yes bundle auth')
      }
    })

    getDoc(quizRef)
    .then((docu) => {
     // console.log(docu.data().id)
     // console.log(auth.currentUser.uid)

      if(!(docu.data().id.includes(auth?.currentUser?.uid))) {
       // console.log('no quiz auth')
        setNoQuizAuth(true)
        if(noQuizAuth && noBundleAuth && noVideoAuth) {
          navigate('/dashboard')
        }
       
        
      }
      else {
       // console.log('yes quiz auth')
      }

    })

      const monitorAuthState = async() => {
        onAuthStateChanged(auth, user => {
          if (!user) {
           // console.log(user.email, 'asd')
            navigate('/')
          }
        })
      }

      monitorAuthState()

    }, [noBundleAuth, noQuizAuth, noVideoAuth])


     useEffect(() => {
      const addImage = async() => {
        const reference = ref(storage, `images/Mock Exam.png`)
        await getDownloadURL(reference).then((x) => {
          setImage(x)
         // console.log(x, 'asdfjlk')
        })

      }
      addImage()
    },[])

    const shuffleArray = array => {
      for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }

      return array
    }

    const [getScore, setGetScore] = useRecoilState(score)
    const [getClicks, setGetClicks] = useRecoilState(clicks)

    useEffect(() => {

     
      

        const getDocuments = async() => {

          setGetScore(0)
          setGetClicks(0)
  
          const docs = query(collection(db, 'Quizzes'))
          const snapshot = await getDocs(docs)
          const tempArr = []
          
        

  
          snapshot.forEach((doc) => {

            doc.data().Questions.map((question) => {
              tempArr.push({Question: question.Question, Answer: question.Answer.Answer, Choices: shuffleArray(question.Choices), Summary: question.Answer.Summary
              })})



            questionsArr.current = shuffleArray(tempArr)

           newInfo.current = questionsArr.current.slice(0,50)

            
            
          })


  
          
  
          
  
        }
  
        getDocuments()

        
  
      }, [])


    const handleLogout = async() => {
      await signOut(auth)
    }

    // timer

    let [timer, setTimer] = useState(100)

    useEffect(() => {
        const interval = setInterval(() => {
          if(timer >= 0) {
            setTimer(timer--)
          }
        }, 30000)

        return () => {
          clearInterval(interval)
        }

        interval()
    }, [timer])


    const StyledFab = styled(Fab)({
      position: 'absolute',
      zIndex: 1,
      top: -30,
      left: 0,
      right: 0,
      margin: '0 auto',
    });

   

  return (

    <Grid>

<Box
          sx={{
            bgcolor: 'background.paper',
            pt: 8,
            pb: 6,
          }}
        >


          <Container maxWidth="md">
          <Card elevation={10} style = {{padding: '20px', borderRadius: '10px'}}>
          <HomeIcon onClick = {() => navigate('/dashboard')}/>

          <CardMedia
        component="img"
        height="140"
        style={{objectFit: 'contain', paddingTop: '30px'}}
        image={image}       
      />

            <Typography
              component="h1"
              variant="h4"
              align="center"
              color="text.primary"
              gutterBottom
            >
            Mock Exam
            </Typography>

           


            <Typography variant="h5" align="center" color="text.secondary" paragraph>
             This section is to break you away from seeing the flashcards in the same order. Which gives you a more test like feeling for what the exam will be like
            </Typography>
            <Stack
              sx={{ pt: 4 }}
              direction="row"
              spacing={2}
              justifyContent="center"
            >
              <Button onClick={() => navigate(-1)} variant="outlined">Go Back</Button>
              <Button onClick={handleLogout} variant="contained">Sign Out</Button>
              
            </Stack>
            </Card>
          </Container>
          
        </Box>




{/* new grid system */}


{!newInfo.current.length && 

<Container maxWidth = 'sm'>



<Card
    

elevation={10}
  sx={{ height: '100%', display: 'flex', flexDirection: 'column', borderRadius: '10px' }}
  style = {{height: '300px', cursor:'pointer'}}
  
>
  
 
 <CardContent sx={{ flexGrow: 1 }}>

  <Typography paddingTop={7}  align='center' color = 'text.secondary'>

  <Lock sx={{fontSize:'80px'}} />
  
  </Typography>


    
    
    <Typography  color= 'text.secondary' variant='h3' align = 'center' paddingBottom={10}>

      
   
  Preparing Exam...
   
    </Typography>
   
  </CardContent>
 
 
 
</Card>

</Container>

}

{(getClicks < 50 && timer != 0) && <Container sx={{ py: 8 }} maxWidth="md">
   {/* <Typography variant= 'h4' gutterBottom   display={'flex'} justifyContent = {'flex-end'}>
  
  Score: {Math.round((getScore/newInfo.current.length) * 100)}%
  Clicks: {getClicks}
  </Typography>  */}
  <Container style = {{display: 'flex', justifyContent: 'flex-end'}}>

  <AppBar position="fixed"  sx={{ top: 'auto', bottom: 0, display: 'flex', justifyContent: 'flex-end', width: '200px', marginRight: '10px', marginBottom: '10px',paddingTop: '5px', borderRadius: '25px' }}>

   

    <Typography align='center'  variant = 'h6' gutterBottom><AccessTime style = {{fontSize: '40px'}}/><span className='blink_me'>:</span> {timer} min</Typography>


   
        

         
          
          
         
        
      </AppBar>


  </Container>

    <Grid container spacing={4}>
      
     
    {newInfo?.current?.map((question, i) => (

<GeneratedQuizCard key={i} question = {question?.Question} answer = {question?.Answer} choices = {question?.Choices}  summary = {question?.Summary}/>

))}
    </Grid>
  </Container>
}


{/* Old grid system */}
   
{(getClicks === 50 || timer === 0) &&

<Container maxWidth = 'sm'>



<Card
    

elevation={10}
  sx={{ height: '100%', display: 'flex', flexDirection: 'column', borderRadius: '10px' }}
  style = {{height: '300px', cursor:'pointer'}}
  
>
  
 
 <CardContent sx={{ flexGrow: 1 }}>
    
    <Typography gutterBottom paddingBottom = '50px' variant="body1" component="h4" align='center' justifyContent = 'center' style={{color: '#5885AF'}}>{timer === 0 && 'No more time remaining'} {getClicks === 50 &&'Test Results Below'}</Typography>
    
    <Typography  color= 'text.secondary' variant='h3' align = 'center' paddingBottom={10}>
   
    Score: {Math.round((getScore/newInfo.current.length) * 100)}%
    
   
    </Typography>
    <Container align = 'center'>

    <Button variant='outlined' onClick={() => window.location.reload()}>Start new quiz</Button>


    </Container>
  </CardContent>
 
 
 
</Card>

</Container>

}

<Container
        maxWidth="md"
        component="footer"
        sx={{
          borderTop: (theme) => `1px solid ${theme.palette.divider}`,
          mt: 8,
          py: [3, 6],
        }}
        align = 'center'
      >
       
        <Typography>
        Copyright © {new Date().getFullYear()}
        </Typography>
        <Typography>
        Contact: jhaelintoliver1@live
        </Typography>
        
      </Container>


</Grid>


    
  )
}

export default QuizGenerator